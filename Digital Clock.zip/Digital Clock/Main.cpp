/*
	DIGITAL CLOCK PROJECT
*/

#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include<windows.h>



int main()
{
	// EXTRA COOL STUFF FOR UI
	// NOTE: to access colors, type color i or color ii in cmd prompt.
	system("color 3"); // Aqua color


	// Declared Clock with time variable
	time_t clock;
	// Called time and set it to NULL since we arent storing elsewhere
	clock = time(NULL);

	// Defined two character arrays for 
	const char am[] = "AM";
	const char pm[] = "PM";

	// Allows user to pull from local time
	struct tm* localtime(const time_t * clock);
	struct tm* tm_info(localtime(&clock));

	// Extracts the hour, minute, and second from the time structure
	int tm_hour = tm_info->tm_hour;
	int tm_min = tm_info->tm_min;
	int tm_sec = tm_info->tm_sec;

	int display_hour = tm_hour;

	
	while (1){

		time(&clock);
		clock = time(NULL);
		localtime(&clock);


		// Conditions to change from AM to PM vice versa
		if (tm_hour == 0) {
			display_hour = 12;
			//printf("%d %s", display_hour, am);
		}
		else if (tm_hour == 12) {
			display_hour = 12;
			//printf("%d %s", display_hour, pm);
		}
		else if (tm_hour < 12) {
			display_hour = tm_hour;
			//printf("%d %s", display_hour, am);
		}
		else if (tm_hour > 12) {
			display_hour = tm_hour - 12;
			//printf("%d : %d : %d %s", display_hour, pm);
		}
		printf("\n");
		



		
		//printf("%d : %d : %d %s", display_hour, tm_info->tm_min, tm_info->tm_sec, pm);
		printf("+-----------------+\n");
		printf("| %02d : %02d : %02d %s |", display_hour, tm_info->tm_min, tm_info->tm_sec, am);
		printf("\n+-----------------+\n");
		
		// updates clock every second
		Sleep(1000);

		// Clears the the previous iteration
		system("cls");
		
		

		// Allows for user to exit clock with a keystroke
		if (_kbhit() && _getch() == 'q') {
			puts("You exited the clock");
			exit(0);
		}
		
	}
	

	return 0;
}
